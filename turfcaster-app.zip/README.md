# Turfcaster

Private AI-driven horse racing prediction app.