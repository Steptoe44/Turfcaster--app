# Turfcaster App

This is the frontend for the Turfcaster horse racing prediction app.